

export type Bid = {
    playerIdx: number;
    pickedDice: number;
    guessedCount: number;
}

export type Move = {
    type: string;
    bid?: Bid;
}

export type IGameState = {
    activePlayerIdx: number;
    playerDicesCount: number[];
    playersHands: number[][];
}

export type BoardState = {
    bidHistory: Bid[];
}

export type IStateTransitionProps = {
    gameState: IGameState;
    boardState: BoardState;
    move?: Move;
}

export type FStateTransition = (props: IStateTransitionProps) => void;