import { IStateTransition, IStateTransitionProps } from "./BluffStateEngineTransitionTypes";
import { gameEngineHelper } from "./GameEngineHelper";
import { StateTransitionProps } from "./IGameStateTypes";

export const bluffStateEngineTransitions: IStateTransition[] = [
    {
        currentState: 'NEW_GAME', nextState: 'NEW_ROUND', makeTransition: newRoundTransition
    },
    {
        currentState: 'NEW_ROUND', nextState: 'WAITING_FOR_PLAYER_MOVE', makeTransition: waitingForPlayerTransition
    },
    {
        currentState: 'WAITING_FOR_PLAYER_MOVE', nextState: 'PLAYER_MOVE_BID', makeTransition: playerMoveBidTransition
    },
    {
        currentState: 'PLAYER_MOVE_BID', nextState: 'WAITING_FOR_PLAYER_MOVE', makeTransition: waitingForPlayerTransition
    },
    {
        currentState: 'WAITING_FOR_PLAYER_MOVE', nextState: 'PLAYER_MOVE_CHALLENGE', makeTransition: playerMoveChallangeTransition
    },
    {
        currentState: 'PLAYER_MOVE_CHALLENGE', nextState: 'END_ROUND'
    },
    {
        currentState: 'END_ROUND', nextState: "END_GAME"
    },
    {
        currentState: 'END_ROUND', nextState: "NEW_ROUND", makeTransition: newRoundTransition
    }
]

function newRoundTransition({ options, gameState, boardState }: IStateTransitionProps) {
    const newBoardState = gameEngineHelper.initBoardState(options, gameState);
    boardState.bidHistory = newBoardState.bidHistory;
    boardState.diceValues = newBoardState.diceValues;
}

function playerMoveBidTransition({ gameState, boardState, move, options }: IStateTransitionProps) {
    if (move?.type !== "bid") {
        throw new Error(`Oczekiwany ruch "BID"`);
    }

    // Dodatkowa walidacja liczby kostek i poprawności licytacji
    const { playerIdx, pickedDice, guessedCount } = move.bid;
    const activePlayerDicesCount = gameState.playerDicesCount[gameState.activePlayerIdx];

    if (playerIdx !== gameState.activePlayerIdx) {
        throw new Error(`Ruch BID może zostać wykonany tylko przez aktywnego gracza`);
    }

    if (pickedDice < 1 || pickedDice > options.diceType || guessedCount < 1) {
        throw new Error(`Niepoprawne wartości dla wybranej kostki lub zgadywanej ilości kostek`);
    }

    if (guessedCount <= activePlayerDicesCount) {
        throw new Error(`Zgadywana liczba kostek musi być większa od liczby posiadanych kostek przez aktywnego gracza`);
    }

    boardState.bidHistory.push(move.bid);
}

function playerMoveChallangeTransition({ gameState, boardState, move }: StateTransitionProps ) {
    if (move?.type !== "challenge") {
        throw new Error(`Oczekiwany ruch "CHALLENGE"`);
    }

    if (boardState.bidHistory.length === 0) {
        throw new Error(`Nie można wyzwać nikogo, jeśli jeszcze nikt nie licytował`);
    }

    const lastBid = boardState.bidHistory[boardState.bidHistory.length - 1];
    const actualDices = gameState.playersHands.reduce((acc, hand) => acc + hand.length, 0);
    const exactBidWasPlaced = lastBid.guessedCount === actualDices - lastBid.pickedDice;

    if (exactBidWasPlaced) {
        for (let i = 0; i < gameState.playersHands.length; i++) {
            if (i !== gameState.activePlayerIdx) {
                gameState.playersHands[i].pop();
            }
        }
    } else {
        gameState.playersHands[gameState.activePlayerIdx].pop();
    }

    boardState.bidHistory = [];
    gameState.playerDicesCount = gameState.playersHands.map(hand => hand.length);
}

function waitingForPlayerTransition({ prevState, gameState, options }: IStateTransitionProps) {
    gameState.activePlayerIdx = prevState === "NEW_ROUND"
        ? gameEngineHelper.firstPlayerIdx(options, gameState)
        : gameEngineHelper.nextPlayerIdx(options, gameState);
}
